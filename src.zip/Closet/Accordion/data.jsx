const data = [
    {
        type: "종류",
        color: "색상",
        texture: "재질",
        style: "스타일",
    },
];

export default data;