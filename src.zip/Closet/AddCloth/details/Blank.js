import React from "react";

function Blank(){

    return(
        <>
        </>
    )
}
export default Blank;