# ClothPick-Team-Project
코디 추천 쇼핑몰 옷픽 Web/App 팀 프로젝트입니다.
