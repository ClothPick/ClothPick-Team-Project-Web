import MPside from "./MPside";
import MyPage from "./MyPage";
import Header from "../Header/closetHeader/Header";
function MyPageMain(){

    return(
        <div className="mpmain">
            <Header/>
            <MPside />
            <MyPage />
        </div>
    )
}
export default MyPageMain;