import MPside from "./MPside";
import Header from "../Header/closetHeader/Header";
import Scrap from "./Scrap";

function Scrap_main(){

    return (
        <div className="scrap_total">
            <Header />
            <MPside/>
            <Scrap />

        </div>
    )
}

export default Scrap_main;