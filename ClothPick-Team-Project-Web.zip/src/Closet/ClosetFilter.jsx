import React from 'react';
import Accordion from './Accordion/Accordion';

// [내 옷장] Filter 기능 - 아코디언 필터

const ClosetFilter = () => {
  return (
    <div>
      <Accordion />
    </div>
  );
};

export default ClosetFilter;